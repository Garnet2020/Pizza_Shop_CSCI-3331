import pizzaHelper.CS3331Pizza;

public class Baker {
    
    // Declared Valuable
    private int pizzasBaked;
   
     // Tracks the total number of pizzas baked by all Bakers
    private static int totalPizzasMade = 0;

    // Constructor for Baker, initializes pizzasBaked
    public Baker() {
        this.pizzasBaked = 0;
        System.out.println("Baker constructor initiated");
    }

    // Method to bake a mushroom pizza
    public CS3331Pizza bakeMushroomPizza() {
        CS3331Pizza pizza = new CS3331Pizza();
        pizza.addMushrooms();
        pizzasBaked++;
        totalPizzasMade++;
        return pizza;
    }

    // Method to bake a pineapple pizza
    public CS3331Pizza bakePineapplePizza() {
        CS3331Pizza pizza = new CS3331Pizza();
        pizza.addPineapple();
        pizzasBaked++;
        totalPizzasMade++;
        return pizza;
    }

    // Method to bake a spinach pizza
    public CS3331Pizza bakeSpinachPizza() {
        CS3331Pizza pizza = new CS3331Pizza();
        pizza.addSpinach();
        pizzasBaked++;
        totalPizzasMade++;
        return pizza;
    }

    // will give an update on the number of pizzas baked by the baker
    public String getWorkUpdate() {
        return "The baker has made " + pizzasBaked + " pizzas";
    }

    // will give the total number of pizzas baked by the baker
    public static String getTotalPizzasMade() {
        return "Total pizzas baked by all bakers: " + totalPizzasMade;
    }
}
