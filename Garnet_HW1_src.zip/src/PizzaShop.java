import pizzaHelper.CS3331Pizza;
import pizzaHelper.CS3331Toppings;
import pizzaHelper.PizzaShopHelper;

/**
 * This is our top-level class that represents a PizzaShop!
 */

public class PizzaShop extends PizzaShopHelper {

    // Declared variables for toppings and baker
    private CS3331Toppings toppings;
    private Baker baker;

    /**
     * This is the constructor of the PizzaShop class. You should initialize all your instalce variables here,
     * and be sure to open shop!
     */
    public PizzaShop() {
        super();
        this.toppings = new CS3331Toppings();
        this.baker = new Baker();

        openShop();
        displayShopUpdate("We are open for business");
    }

    // Order 1: Mushroom pizza
    @Override
    public void order1() {
        System.out.println("Order 1 button clicked!");
        CS3331Pizza pizza = this.baker.bakeMushroomPizza();
        updateShopStatus(pizza);
    }

    // Order 2:Pineapple pizza and add peppers
    @Override
    public void order2() {
        System.out.println("Order 2 button clicked!");
        CS3331Pizza pizza = this.baker.bakePineapplePizza();
        this.toppings.addPeppers(pizza);
        updateShopStatus(pizza);
    }

    // Order 3: Spinach pizza and add tomatoes
    @Override
    public void order3() {
        System.out.println("Order 3 button clicked!");
        CS3331Pizza pizza = this.baker.bakeSpinachPizza();
        this.toppings.addTomatoes(pizza);
        updateShopStatus(pizza);
    }

    // Order 4: Spinach pizza and add both peppers and tomatoes
    @Override
    public void order4() {
        System.out.println("Order 4 button clicked!");
        CS3331Pizza pizza = this.baker.bakeSpinachPizza();
        this.toppings.addPeppers(pizza);
        this.toppings.addTomatoes(pizza);
        updateShopStatus(pizza);
    }

    // Method to update shop status (price and work update)
    private void updateShopStatus(CS3331Pizza pizza) {
        displayPrice(pizza);
        displayShopUpdate(this.baker.getWorkUpdate());
        System.out.println(Baker.getTotalPizzasMade());
    }
}
